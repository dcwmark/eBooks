package musicstore;

import java.rmi.RemoteException;
import javax.ejb.*;


public interface InventoryHome extends EJBHome {
    // create() goes here
}
