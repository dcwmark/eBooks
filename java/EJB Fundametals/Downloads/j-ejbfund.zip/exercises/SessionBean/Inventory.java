package musicstore;

import java.util.*;
import java.rmi.RemoteException;
import javax.ejb.*;


public interface Inventory extends EJBObject {
    // addInventory() service goes here
}
