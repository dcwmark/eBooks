package musicstore;

import java.rmi.RemoteException;
import javax.ejb.*;


public interface MusicCD extends EJBObject {
    // need to define accessors and mutators for the
    // title, artist, type, and price fields
}
