package musicstore;

import java.rmi.RemoteException;
import javax.ejb.*;


public interface MusicCDHome extends EJBHome {
    // need to define a create method here

    // need to define a findByPrimaryKey method here
}
