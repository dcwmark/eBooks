import java.util.*;

public class CaseInsensitiveComparator implements Comparator {

  // Compare two elements
}
