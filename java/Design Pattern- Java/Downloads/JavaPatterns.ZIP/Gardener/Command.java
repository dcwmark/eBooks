public interface Command
{
  public void Execute();
}

