public class ParseObject
{
   public static final int VERB=1000, VAR = 1010, MULTVAR = 1020;
   protected int value;
   protected int type;

   public int getValue() {return value;}
   public int getType() {return type;}
}
