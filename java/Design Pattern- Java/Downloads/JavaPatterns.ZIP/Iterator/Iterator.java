public interface Iterator
{
public Object First();
public Object Next();
public boolean isDone();
public Object CurrentItem();
}
