Data Access Command Beans
-------------------------

The implementations of the abstract super classes BaseReadCommand and BaseUpdateCommand, as well as the InsertEmployeeCommand and QueryEmployeeByNameCommand classes are contained in src. 

Note that the BaseReadCommand uses a RowSet to simplify its implementation. RowSets are part of the JDBC 2.0 optional package, and joined core JDBC as of JDBC 3.0. The example here uses Sun�s free CachedRowSet implementation of the RowSet interface.