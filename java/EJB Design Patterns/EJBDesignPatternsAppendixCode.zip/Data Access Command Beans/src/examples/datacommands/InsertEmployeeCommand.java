package examples.datacommands;

import java.sql.*;
import javax.sql.*;

/**
 * InsertEmployeeCommand, this class
 * is the usecase specific Command bean that
 * an application developer would write.
 */
public class InsertEmployeeCommand extends BaseUpdateCommand
{

    static String statement = "insert into Employees (EMPLOYEEID, NAME, EMAIL) values (?,?,?)";
    static final String dataSourceJNDI = "bookPool";
    /**
     * Passes parent class the usecase specific sql statement to use
     */
    protected InsertEmployeeCommand() throws DataCommandException
    {

        super(dataSourceJNDI, statement);
    }

    public void setEmail(String anEmail) throws DataCommandException
    {
        try
        {
            pstmt.setString(3, anEmail);
        } catch (SQLException e)
        {
            throw new DataCommandException(e.getMessage());
        }
    }

    public void setId(int id) throws DataCommandException
    {
        try
        {
            pstmt.setInt(1, id);
        } catch (SQLException e)
        {
            throw new DataCommandException(e.getMessage());
        }
    }

    public void setName(String aName) throws DataCommandException
    {
        try
        {
            pstmt.setString(2, aName);
        } catch (SQLException e)
        {
            throw new DataCommandException(e.getMessage());
        }

    }
}