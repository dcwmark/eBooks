package examples.datacommands;

import javax.sql.*;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.sql.*;
import sun.jdbc.rowset.CachedRowSet;

/**
 * The Super class for any data command beans Read from the
 * database.
 */
abstract class BaseReadCommand {

	protected PreparedStatement pstmt;
	protected CachedRowSet rowSet = null;
	private Connection con;

	protected BaseReadCommand ( String jndiName, String statement ) throws DataCommandException
	{
        InitialContext ctx = null;
        try
        {
            ctx = new InitialContext();
            DataSource ds = (javax.sql.DataSource) ctx.lookup(jndiName);
            con = ds.getConnection();
            pstmt = con.prepareStatement(statement);
        }
        catch (NamingException e)
        {
            throw new DataCommandException(e.getMessage());
        }
        catch (SQLException e)
        {
            throw new DataCommandException(e.getMessage());
        }
	}

	public void execute() throws DataCommandException
	{
        try
        {
            rowSet = new CachedRowSet();
            rowSet.populate(pstmt.executeQuery());
            rowSet.beforeFirst();
            this.release();
        } catch (SQLException e)
        {
            throw new DataCommandException(e.getMessage());
        }
    }
	public boolean next() throws DataCommandException
	{
        try
        {
            return rowSet.next();
        } catch (SQLException e)
        {
            throw new DataCommandException(e.getMessage());
        }
	}
	private void release() throws SQLException
	{
        if (pstmt != null) pstmt.close();
        if (con != null) con.close();
 	}
}