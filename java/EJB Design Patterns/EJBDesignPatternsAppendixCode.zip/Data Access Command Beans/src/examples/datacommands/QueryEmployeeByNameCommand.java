package examples.datacommands;


import java.sql.*;
import javax.sql.*;

/**
 * A usecase specific querying object
 **/
public class QueryEmployeeByNameCommand extends BaseReadCommand
{

    static final String statement = "select EMPLOYEEID, NAME, EMAIL from Employees where NAME = ?";
    static final String dataSourceJNDI = "bookPool";

    protected QueryEmployeeByNameCommand() throws DataCommandException
    {
        super(dataSourceJNDI, statement);
    }

    public String getEmail() throws DataCommandException
    {
        try
        {
            return rowSet.getString(3);
        } catch (SQLException e)
        {
            throw new DataCommandException(e.getMessage());
        }
    }

    public int getId() throws DataCommandException
    {
        try
        {
            return rowSet.getInt(1);
        } catch (SQLException e)
        {
            throw new DataCommandException(e.getMessage());
        }
    }

    public String getName() throws DataCommandException
    {
        try
        {
            return rowSet.getString(2);
        } catch (SQLException e)
        {
            throw new DataCommandException(e.getMessage());
        }
    }

    public void setName(String aName) throws DataCommandException
    {
        try
        {
            pstmt.setString(1, aName);
        } catch (SQLException e)
        {
            throw new DataCommandException(e.getMessage());
        }
    }
}

