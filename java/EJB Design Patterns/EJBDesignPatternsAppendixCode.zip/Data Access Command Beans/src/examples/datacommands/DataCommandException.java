/*
 * Created by IntelliJ IDEA.
 * User: Floyd Marinescu
 * Date: Oct 6, 2001
 * Time: 6:46:42 PM
 * To change template for new class use 
 * Code Style | Class Templates options (Tools | IDE Options).
 */
package examples.datacommands;

public class DataCommandException extends Exception
{

    public DataCommandException()
    {
    }

    public DataCommandException(String s)
    {
        super(s);
    }

}
