package examples.datacommands;

import javax.sql.*;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.ejb.EJBException;
import java.sql.*;

/**
 * The Super class for any data command beans that Create, Update or Delete
 * This class is reusable across projects, all proj. specific data
 * (Datasource JDNI and SQl String) are left to the subclasses
 */
abstract class BaseUpdateCommand {

	protected PreparedStatement pstmt;
	private Connection con;

	protected BaseUpdateCommand ( String jndiName, String statement ) throws DataCommandException
    {
        InitialContext ctx = null;
        try
        {
            ctx = new InitialContext();
            DataSource ds = (javax.sql.DataSource) ctx.lookup(jndiName);
            con = ds.getConnection();
            pstmt = con.prepareStatement(statement);
        }
        catch (NamingException e)
        {
            throw new DataCommandException(e.getMessage());
        }
        catch (SQLException e)
        {
            throw new DataCommandException(e.getMessage());
        }
	}
	public int execute() throws DataCommandException
	{
        try
        {
            //execute update, return the rowcount
            int updateCount = pstmt.executeUpdate();
            this.release();
            return updateCount;
        } catch (SQLException e)
        {
            throw new DataCommandException(e.getMessage());
        }
	}
	private void release() throws SQLException
	{
        if (pstmt != null) pstmt.close();
        if (con != null) con.close();
	}
}