Sequence Blocks
---------------

Included is a complete implementation of the Sequence Block pattern, based on a submission by Jonathan Weedon from Borland Corporation.  The Sequence entity bean exposes only Local Interfaces (it is only called by the Sequence Session Bean). The Sequence Session Bean exposes both Local and Remote (should be called by Local Interfaces in production, Remote is provided for testing purposes).  Ejb-jar.xml descriptors are also included. 