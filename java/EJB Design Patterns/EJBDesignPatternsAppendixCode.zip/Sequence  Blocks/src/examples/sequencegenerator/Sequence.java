package examples.sequencegenerator;

// Sequence.java

public interface Sequence extends javax.ejb.EJBLocalObject {

  public int getValueAfterIncrementingBy(int blockSize);
}
