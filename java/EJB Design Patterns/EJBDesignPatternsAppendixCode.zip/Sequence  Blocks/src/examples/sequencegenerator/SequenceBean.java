package examples.sequencegenerator;

// SequenceBean.java

import javax.ejb.*;

abstract public class SequenceBean implements EntityBean {

	public void ejbActivate() {}
	public String ejbCreate(String name) 
	{
		this.setName(name);
		this.setIndex(0);
		return null;
	}
	public void ejbLoad() {}
	public void ejbPassivate() {}
	public void ejbPostCreate(String name) {}
	public void ejbRemove() {}
	public void ejbStore() {}
	abstract public int getIndex();
	abstract public String getName();
	public int getValueAfterIncrementingBy(int blockSize) 
	{
        this.setIndex(this.getIndex()+ blockSize);
		return this.getIndex();
	}
	public void setEntityContext(EntityContext unused) {}
	abstract public void setIndex(int newIndex);
	abstract public void setName(java.lang.String newName);
	public void unsetEntityContext() {}
}
