package examples.sequencegenerator;

// SequenceGenerator.java

public interface SequenceSessionLocal extends javax.ejb.EJBLocalObject {

  public int getNextSequenceNumber(String name);
}
