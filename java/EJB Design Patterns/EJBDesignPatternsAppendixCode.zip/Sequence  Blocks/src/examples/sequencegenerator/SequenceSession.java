package examples.sequencegenerator;
import java.rmi.*;
// SequenceGenerator.java

public interface SequenceSession extends javax.ejb.EJBObject {

  public int getNextSequenceNumber(String name) throws RemoteException;
}
