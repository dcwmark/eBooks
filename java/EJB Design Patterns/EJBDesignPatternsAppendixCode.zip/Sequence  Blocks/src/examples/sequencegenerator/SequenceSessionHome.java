package examples.sequencegenerator;

// SequenceGeneratorHome.java
import javax.ejb.*;
import java.rmi.*;
public interface SequenceSessionHome extends javax.ejb.EJBHome {
  SequenceSession create() throws CreateException, RemoteException;
}
