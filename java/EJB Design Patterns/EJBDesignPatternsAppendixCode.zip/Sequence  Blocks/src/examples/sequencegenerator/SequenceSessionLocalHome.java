package examples.sequencegenerator;

// SequenceGeneratorHome.java
import javax.ejb.*;

public interface SequenceSessionLocalHome extends javax.ejb.EJBLocalHome {
  SequenceSessionLocal create() throws CreateException;
}
