package examples.sequencegenerator;

// SequenceHome.java

public interface SequenceLocalHome extends javax.ejb.EJBLocalHome {

  Sequence create(String name) throws  javax.ejb.CreateException;
  Sequence findByPrimaryKey(String name) throws  javax.ejb.FinderException;
}
