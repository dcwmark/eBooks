Thanks for downloading the source code for EJB Design Patterns. Here you will find soft copies of all the code and resources from the book appendix, except for the ForumServicesDelegate example.

If you are interested in learning these patterns hands on, you might consider taking the "EJB for Architects" course at the Middleware Company (http://www.middlware-company.com), where you can learn all of these patterns and more.

Enjoy,

Floyd Marinescu
Author, EJB Design Patterns
Director of TheServerSide.com

--------------------------------------------------------------
Legal Stuff
--------------------------------------------------------------
All these code examples are provided for educational purposes only, use at your own risk.

This document and all other data within this archive is (c) 2001 by
The Middleware Company and is published by John Wiley & Sons, Inc.