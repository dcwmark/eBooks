
package examples.command;

interface CommandTarget {
        Command executeCommand(Command aCommand) throws CommandException;
}
