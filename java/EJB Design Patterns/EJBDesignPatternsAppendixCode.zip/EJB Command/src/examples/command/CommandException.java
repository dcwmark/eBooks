package examples.command;

public class CommandException extends Exception  {

    Exception wrappedException;

    public CommandException()
    {
    }
    public CommandException(Exception e)
    {
        this.wrappedException = e;
    }

    Exception getWrappedException()
    {
        return wrappedException;
    }

    public CommandException(String s) {
        super(s);
    }
}
