package examples.command;

import javax.ejb.*;
import java.rmi.RemoteException;
import javax.naming.*;


public class CommandServerBean implements SessionBean {

	SessionContext ctx;	

  public void CommandServer() {
  }

public Command executeCommand(Command aCommand) throws CommandException
{
    try
    {
        aCommand.execute();
    }
    catch (CommandException e)
    {
        ctx.setRollbackOnly();
        throw e;
    }

    return aCommand;

}
    public void ejbActivate() throws EJBException,
        java.rmi.RemoteException
    {
    }
    public void ejbCreate() throws CreateException {

	   }
    public void ejbPassivate() throws EJBException,
        java.rmi.RemoteException
    {
    }
    public void ejbRemove() throws EJBException,
        java.rmi.RemoteException 
    {
    }
    public void setSessionContext(final SessionContext p1)
    throws EJBException, java.rmi.RemoteException {

	    this.ctx = p1;
    }
}
