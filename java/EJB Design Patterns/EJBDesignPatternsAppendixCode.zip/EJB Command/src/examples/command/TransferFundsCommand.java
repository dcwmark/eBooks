package examples.command;

import examples.dualpersistent.AccountHome;
import examples.dualpersistent.Account;
import examples.dualpersistent.ProcessingErrorException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import javax.ejb.FinderException;
import java.rmi.RemoteException;
import java.io.Serializable;

public class TransferFundsCommand extends Command implements Serializable {

    String withdrawAccountID;
    String depositAccountID;
    double transferAmount;

    double withdrawAccountBalance;
    double depositAccountBalance;

    public void setWithdrawAccountID(String withdrawAccountID) {
        this.withdrawAccountID = withdrawAccountID;
    }

    public void setDepositAccountID(String depositAccountID) {
        this.depositAccountID = depositAccountID;
    }

    public void setTransferAmount(double transferAmount) {
        this.transferAmount = transferAmount;
    }


    public double getDepositAccountBalance() {
        return depositAccountBalance;
    }

    public double getWithdrawAccountBalance() {
        return withdrawAccountBalance;
    }

    public void execute() throws CommandException
    {
        //at this point we are inside the EJB Server
        try {

            InitialContext ctx = new InitialContext();
            AccountHome home = (AccountHome) PortableRemoteObject.narrow(ctx.lookup("dualPersistent"), AccountHome.class);

            //locate accounts and perform transfer
            Account account1 = home.findByPrimaryKey(withdrawAccountID);
            Account account2 = home.findByPrimaryKey(depositAccountID);

            account1.withdraw(this.transferAmount);
            account2.deposit(this.transferAmount);

            //populate command with final balances
            this.depositAccountBalance = account2.balance();
            this.withdrawAccountBalance = account1.balance();
        }
        catch (Exception e)
        {
            //wrap the exception as a command execption and throw to client
            throw new CommandException(e);
        }
    }

    public TransferFundsCommand()
    {
    }
}
