
package examples.command;

import javax.rmi.PortableRemoteObject;
import javax.ejb.CreateException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.rmi.RemoteException;

public class EJBCommandTarget implements CommandTarget {

    private CommandServerHome serverHome;

        public EJBCommandTarget()
        {
            try {
                Context ctx = new InitialContext(System.getProperties());
                Object obj = ctx.lookup("CommandServer");
                System.out.println(obj);
                this.serverHome = (CommandServerHome) PortableRemoteObject.narrow(obj, CommandServerHome.class );
            } catch (NamingException e) {
                e.printStackTrace();
            } catch (ClassCastException e) {
                e.printStackTrace();
            }
        }

    public Command executeCommand(Command aCommand) throws CommandException
    {

        try {
            CommandServer aCommandServer = serverHome.create();
            aCommand = aCommandServer.executeCommand(aCommand);
            return aCommand;

        } catch (Exception e)
        {
            throw new CommandException(e);
        }
      }
}
