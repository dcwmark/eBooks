package examples.command;

import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface CommandServer extends javax.ejb.EJBObject {

public Command executeCommand(Command aCommand) throws RemoteException, CommandException;
}
