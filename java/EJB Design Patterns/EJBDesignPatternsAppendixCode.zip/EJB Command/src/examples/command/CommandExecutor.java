/*
 * Created by IntelliJ IDEA.
 * User: Floyd Marinescu
 * Date: Sep 23, 2001
 * Time: 4:38:51 PM
 * To change template for new class use 
 * Code Style | Class Templates options (Tools | IDE Options).
 */
package examples.command;

public class CommandExecutor
{
    private static EJBCommandTarget ejbTarget = new EJBCommandTarget();

    //execute command, overwriting memory reference of the passed in command to that of the new one
    public static Command execute(Command aCommand) throws CommandException
    {

        //at this point, a real implementation would use a properties file
        //to determine which command target (EJB, Local, Corba, etc) to use
        //for this particular command, as well as which deployed CommandServer
        //to use (inorder to run commands in different under different
        //transaction configurations)
        return ejbTarget.executeCommand(aCommand);

    }

}
