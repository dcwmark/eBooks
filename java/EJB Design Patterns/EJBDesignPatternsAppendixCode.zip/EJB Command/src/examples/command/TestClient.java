package examples.command;

import javax.ejb.*;
import javax.naming.*;
import java.rmi.*;
import javax.rmi.*;
import java.util.*;

/**
 * Sample client code which manipulates a Bank Account Entity Bean.
 */
public class TestClient {

	public static void main(String[] args) throws Exception {

		try {

            TransferFundsCommand transferCommand = new TransferFundsCommand();
            transferCommand.setDepositAccountID("1");
            transferCommand.setWithdrawAccountID("2");
            transferCommand.setTransferAmount(50);

System.out.println("before "+ transferCommand.hashCode());

            transferCommand = (TransferFundsCommand) CommandExecutor.execute(transferCommand);

System.out.println("after " +transferCommand.hashCode());

            System.out.println(transferCommand.getDepositAccountBalance());
            System.out.println(transferCommand.getWithdrawAccountBalance());

		}
		catch (CommandException e) {
			System.out.println(e.getWrappedException().getMessage());
			e.printStackTrace();
		}
	}
}
