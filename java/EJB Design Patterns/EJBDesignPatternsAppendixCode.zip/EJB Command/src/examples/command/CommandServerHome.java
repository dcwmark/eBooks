package examples.command;

import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface CommandServerHome extends javax.ejb.EJBHome {

    public CommandServer create() throws RemoteException, CreateException;
}
