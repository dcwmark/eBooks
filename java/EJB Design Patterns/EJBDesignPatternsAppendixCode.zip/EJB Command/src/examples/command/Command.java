package examples.command;

import java.io.Serializable;

public abstract class Command implements Serializable {

    public abstract void execute() throws CommandException;

}
