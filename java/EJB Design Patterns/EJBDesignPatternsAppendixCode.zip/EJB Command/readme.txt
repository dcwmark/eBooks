EJB Command Pattern
-------------------

Included here is a very simple implementation of the command pattern, including routing logic components (CommandExecutor and EJBCommandTarget)  and a command server  (CommandServerBean), including a bank account transfer command. 

This source is a super simplified version inspired by IBM�s Command framework, and is provided to illustrate the concepts of the command pattern only, use at your own risk. :)

Note:
The 'Transfer Funds Command' assumes that the Dual Persistent Entity Bean Account Example is deployed.