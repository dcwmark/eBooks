Dual Persistent Entity Bean
---------------------------

Included is the code example of the bank account entity bean inheritance relationship and deployment descriptors.  These classes can compiled and then deployed in CMP or BMP by just swapping the provided deployment descriptors (see deployment\bmp or deployment\cmp).

