package examples.dualpersistent;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Vector;
import javax.ejb.*;
import javax.naming.*;
import javax.sql.DataSource;

abstract public class AccountCMPBean implements EntityBean {

  protected EntityContext ctx;

    /**
	 * container managed fields
	 */
	abstract public String getAccountId();
	abstract public double getBalance();
    abstract public void setAccountId(String val);
	abstract public void setBalance(double val);

    /**
     * Developer implemented Business Methods
     */
    public double balance()
    {
        return getBalance();
    }

    public double deposit(double amount)
    {
         setBalance(getBalance() + amount);
         return getBalance();
    }

    public double withdraw(double amount)
    throws ProcessingErrorException
    {

        if (amount > getBalance())
        {
            throw new ProcessingErrorException("Attempt to withdraw too much");
        }

        setBalance(getBalance() - amount);
        return getBalance();

    }

   public String ejbCreate(String accountId, double initialBalance)
    throws CreateException
   {
       setAccountId(accountId);
       setBalance(initialBalance);

       return null;
   }

   /**
    * Container required methods - implemented by the CMP engine
    */
   public AccountCMPBean() {}
   public void ejbActivate() {}
   public void ejbLoad() {}
   public void ejbPassivate() {}
   public void ejbPostCreate(String accountId,double initialBalance){}
   public void ejbRemove() throws RemoveException {}
   public void ejbStore() {}


   /**
    * The usual Plumbing
    */
   public void setEntityContext(EntityContext ctx)
   {
      this.ctx = ctx;
   }

  public void unsetEntityContext()
  {
      this.ctx = null;
  }

}
