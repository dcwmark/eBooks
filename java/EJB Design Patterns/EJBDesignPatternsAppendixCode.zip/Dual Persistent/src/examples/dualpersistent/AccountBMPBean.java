package examples.dualpersistent;

import java.io.Serializable;
import java.util.*;
import javax.ejb.*;
import javax.naming.*;
import java.sql.*;
import javax.sql.*;

public class AccountBMPBean extends AccountCMPBean implements EntityBean
{

    private String accountId;
    private double balance;

    public String getAccountId()
    {
        return accountId;
    }

    public double getBalance()
    {
        return balance;
    }

    public void setAccountId(String val)
    {
        this.accountId = val;
    }

    public void setBalance(double val)
    {
        this.balance = val;
    }

    public String ejbCreate(String accountId, double initialBalance) throws CreateException
    {
        //delegate to super class for validation checks, etc.
        super.ejbCreate(accountId, initialBalance);

        Connection con = null;
        PreparedStatement ps = null;

        try
        {
            con = getConnection();
            ps = con.prepareStatement("insert into Accounts (id, balance) values (?, ?)");
            ps.setString(1, accountId);
            ps.setDouble(2, balance);
            if (ps.executeUpdate() != 1)
            {
                throw new CreateException();
            }

            return accountId;
        } catch (SQLException sqe)
        {
            throw new CreateException();
        } finally
        {
            try
            {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e)
            {
                throw new EJBException(e);
            }
        }
    }


    public Collection ejbFindBigAccounts(double balanceGreaterThan)
    {
        Connection con = null;
        PreparedStatement ps = null;

        try
        {
            con = getConnection();
            ps = con.prepareStatement("select id from Accounts where balance > ?");
            ps.setDouble(1, balanceGreaterThan);
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();
            Vector v = new Vector();
            String pk;
            while (rs.next())
            {
                pk = rs.getString(1);
                v.addElement(pk);
            }
            return v;
        } catch (SQLException e)
        {
            throw new EJBException(e);
        } finally
        {
            try
            {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e)
            {
                throw new EJBException(e);
            }
        }
    }


    public String ejbFindByPrimaryKey(String pk) throws ObjectNotFoundException
    {
        Connection con = null;
        PreparedStatement ps = null;

        try
        {
            con = getConnection();
            ps = con.prepareStatement("select balance from Accounts where id = ?");
            ps.setString(1, pk);
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();
            if (rs.next())
                balance = rs.getDouble(1);
            else
                throw new ObjectNotFoundException();
        } catch (SQLException sqe)
        {
            throw new EJBException(sqe);
        } finally
        {
            try
            {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e)
            {
                System.out.println("Error closing JDBC resourcest: " + e);
                throw new EJBException(e);
            }
        }


        return pk;
    }


    public void ejbLoad()
    {
        Connection con = null;
        PreparedStatement ps = null;
        accountId = (String) ctx.getPrimaryKey();

        try
        {
            con = getConnection();
            ps = con.prepareStatement("select balance from Accounts where id = ?");
            ps.setString(1, accountId);
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();

            if (rs.next())
                balance = rs.getDouble(1);
            else
                throw new NoSuchEntityException();

        } catch (SQLException sqe)
        {

            throw new EJBException(sqe);
        } finally
        {
            try
            {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e)
            {
                System.out.println("Error closing JDBC resourcest: " + e);
                throw new EJBException(e);
            }
        }
    }


    public void ejbPostCreate(String accountId, double initialBalance)
    {
    }


    public void ejbRemove()
    {

        Connection con = null;
        PreparedStatement ps = null;

        try
        {
            con = getConnection();
            accountId = (String) ctx.getPrimaryKey();

            ps = con.prepareStatement("delete from Accounts where id = ?");
            ps.setString(1, accountId);

            if (!(ps.executeUpdate() > 0))
            {
                throw new NoSuchEntityException();
            }
        } catch (SQLException e)
        {
            throw new EJBException(e);
        }

    }


    public void ejbStore()
    {
        Connection con = null;
        PreparedStatement ps = null;

        try
        {
            con = getConnection();
            ps = con.prepareStatement("update Accounts set balance = ? where id = ?");
            ps.setDouble(1, balance);
            ps.setString(2, accountId);
            if (!(ps.executeUpdate() > 0))
                throw new NoSuchEntityException();
        } catch (SQLException sqe)
        {
            throw new EJBException(sqe);
        } finally
        {
            try
            {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e)
            {
                System.out.println("Error closing JDBC resourcest: " + e);
                throw new EJBException(e);
            }
        }
    }


    private Connection getConnection() throws SQLException
    {
        InitialContext ctx = null;
        try
        {
            ctx = new InitialContext();
            DataSource ds = (javax.sql.DataSource)
                    ctx.lookup("ejbPool");
            return ds.getConnection();
        } catch (NamingException e)
        {
            throw new EJBException(e);
        }
    }


}

