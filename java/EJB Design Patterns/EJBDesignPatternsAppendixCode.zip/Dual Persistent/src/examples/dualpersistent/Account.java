package examples.dualpersistent;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

public interface Account extends EJBObject {

    public double balance() throws RemoteException;
    public double deposit(double amount) throws RemoteException;
    public double withdraw(double amount) throws ProcessingErrorException, RemoteException;

}
