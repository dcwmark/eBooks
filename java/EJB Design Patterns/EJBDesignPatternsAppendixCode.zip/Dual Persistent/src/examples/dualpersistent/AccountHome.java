package examples.dualpersistent;

import javax.ejb.*;
import java.rmi.RemoteException;
import java.util.Collection;


public interface AccountHome extends EJBHome {

  public Account create(String accountId, double initialBalance)
    throws CreateException, RemoteException;

    public Account findByPrimaryKey(String primaryKey)
           throws FinderException, RemoteException;

    public Collection findBigAccounts(double balanceGreaterThan)
           throws FinderException, RemoteException;

}
