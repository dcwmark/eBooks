package examples.dualpersistent;

public class ProcessingErrorException extends Exception {

  public ProcessingErrorException() {}
  public ProcessingErrorException(String message) {super(message);}
}
